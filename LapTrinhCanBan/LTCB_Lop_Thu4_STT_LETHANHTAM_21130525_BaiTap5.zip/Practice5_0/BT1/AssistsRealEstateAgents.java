package BT1;

public interface AssistsRealEstateAgents {

}

