package BT1;

public class MTHouse implements AssistsRealEstateAgents{

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "";
	}
}
