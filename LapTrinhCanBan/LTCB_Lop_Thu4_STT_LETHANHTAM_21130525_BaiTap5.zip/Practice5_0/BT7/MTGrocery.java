package BT7;


public class MTGrocery implements IGroceryItems{

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "";
	}
	@Override
	public int howmany() {
		// TODO Auto-generated method stub
		return 0;
	}
	
}
