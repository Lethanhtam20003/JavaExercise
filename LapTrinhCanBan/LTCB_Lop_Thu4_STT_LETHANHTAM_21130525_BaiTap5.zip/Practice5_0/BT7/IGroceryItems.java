package BT7;

public interface IGroceryItems {
	public int 	howmany();
}
