package BT3;

public interface IGrades {

}
