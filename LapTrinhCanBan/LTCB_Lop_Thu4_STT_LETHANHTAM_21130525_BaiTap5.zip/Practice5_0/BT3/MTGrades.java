package BT3;

public class MTGrades implements IGrades {
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "";
	}
}
