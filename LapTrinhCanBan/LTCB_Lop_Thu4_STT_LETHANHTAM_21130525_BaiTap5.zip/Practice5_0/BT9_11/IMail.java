package BT9_11;


public interface IMail {
	public IMail softByDate();
	public IMail insertInDateOrther(MessagesMail m);
}
