package BT6;

public interface IDirectory {

	public IDirectory whoseNumber(String number);
	

	public IDirectory phoneNumber(int name);
}
