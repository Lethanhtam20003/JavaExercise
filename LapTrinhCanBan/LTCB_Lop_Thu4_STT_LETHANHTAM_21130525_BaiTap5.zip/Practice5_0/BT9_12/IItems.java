
package BT9_12;

public interface IItems {
	public int howMany();
	public String brandList();
	public double highestPrice();
	
}