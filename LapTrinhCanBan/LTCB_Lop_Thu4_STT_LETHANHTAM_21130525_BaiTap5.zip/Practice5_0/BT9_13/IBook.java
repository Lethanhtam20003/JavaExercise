package BT9_13;


public interface IBook {
	public IBook thisAuthor(String authorName);
	
	public IBook softByTitle();
	public IBook inserInTitleOrther(ABook b);
}
