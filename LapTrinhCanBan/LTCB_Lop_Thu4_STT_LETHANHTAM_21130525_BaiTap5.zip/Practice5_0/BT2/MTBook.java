package BT2;

public class MTBook implements IBook{
	 @Override
	public String toString() {
		// TODO Auto-generated method stub
		return "";
	}
}