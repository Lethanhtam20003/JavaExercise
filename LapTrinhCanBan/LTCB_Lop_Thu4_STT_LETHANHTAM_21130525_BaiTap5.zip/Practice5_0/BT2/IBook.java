package BT2;

public interface IBook {

}
