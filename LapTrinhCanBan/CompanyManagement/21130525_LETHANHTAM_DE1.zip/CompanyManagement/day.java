package CompanyManagement;

public class day {
	private int day;
	private int month;
	private int year;
	public day(int day, int month, int year) {
		this.day = day;
		this.month = month;
		this.year = year;
	}
	
}
