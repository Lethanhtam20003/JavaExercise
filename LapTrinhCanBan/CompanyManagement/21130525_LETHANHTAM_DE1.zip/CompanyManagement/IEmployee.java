package CompanyManagement;

public interface IEmployee {
	public abstract int howmanyEmployee();
	public abstract IEmployee getDrivers(String vehicle);
}
