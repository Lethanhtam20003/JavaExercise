package CompanyManagement;

import junit.framework.TestCase;

public class IEmployeeTest extends TestCase {
	public void testConstructor() {
		
	}
}
