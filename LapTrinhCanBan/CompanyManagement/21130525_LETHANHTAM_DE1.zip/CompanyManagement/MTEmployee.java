package CompanyManagement;

public class MTEmployee implements IEmployee {

	@Override
	public int howmanyEmployee() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public IEmployee getDrivers(String vehicle) {
		// TODO Auto-generated method stub
		return null;
	}

}
